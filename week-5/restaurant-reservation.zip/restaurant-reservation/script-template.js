/*
  Pragmatic JavaScript
  Chapter 2
  Programming Assignment

  Author:
  Date:
  Filename:
*/

// Create an in-memory object array for each table in the restaurant
let tables = [
  // Add your table objects here
];

// Create a function reserveTable
function reserveTable(tableNumber, callback, time) {
  // Add your code here
}

// When the form is submitted, call the reserveTable function
document
  .getElementById("reservationForm")
  .addEventListener("submit", function (e) {
    // Add your code here
  });
