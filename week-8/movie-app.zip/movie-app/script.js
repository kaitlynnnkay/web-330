/*
  Pragmatic JavaScript
  Chapter 4
  Programming Assignment

  Author:
  Date:
  Filename:
*/

"use strict";

const movies = [
  // Add your movie objects here
];

function fetchMovie(title) {
  // Implement this function
}

document.getElementById("movie-form").addEventListener("submit", async (event) => {
  // Implement this function
});