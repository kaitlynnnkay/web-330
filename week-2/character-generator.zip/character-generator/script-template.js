/*
  Pragmatic JavaScript
  Chapter 1
  Programming Assignment

  Author:
  Date:
  Filename:
*/

"use strict";

function createCharacter(name, gender, characterClass) {
  // TODO: Implement this function
}

document.getElementById("generateHero").addEventListener("click", function(e) {
  e.preventDefault();

  // TODO: Get form values

  // TODO: Create character

  // TODO: Display character information
});